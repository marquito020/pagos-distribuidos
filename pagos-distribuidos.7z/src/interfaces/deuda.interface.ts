export interface Deuda {
    id?: number;
    monto: number;
    saldo: number;
}