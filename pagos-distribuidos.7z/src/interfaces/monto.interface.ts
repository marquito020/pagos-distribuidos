export interface Monto {
    sum: number;
}