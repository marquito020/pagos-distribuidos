export interface Persona {
    id?: number;
    nombre: string;
    apellido: string;
}